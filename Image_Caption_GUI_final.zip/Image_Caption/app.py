from flask import Flask, render_template, request
import numpy as np 
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from keras.applications.inception_v3 import InceptionV3, preprocess_input
from keras.preprocessing.image import load_img, img_to_array

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 1

base_model = InceptionV3(weights = 'imagenet')
model = Model(base_model.input, base_model.layers[-2].output)

def preprocess_img(img_path):
	img = load_img(img_path, target_size = (299, 299))
	x = img_to_array(img)
	x = np.expand_dims(x, axis = 0)
	x = preprocess_input(x)
	return x

def encode(image):
	image = preprocess_img(image)
	vec = model.predict(image)
	vec = np.reshape(vec, (vec.shape[1]))
	return vec


vocab = np.load('./vocab.npy')
max_length = 34
model1 = load_model('./modelJ.h5')

ixtoword = {}
wordtoix = {}

ix = 1
for word in vocab:
    wordtoix[word] = ix
    ixtoword[ix] = word
    ix += 1

def predict(image):
    pic = encode(image).reshape(1, 2048)
    caption = generate_caption(pic)
    return caption


def generate_caption(pic):
    start = 'start'
    for i in range(max_length):
        seq = [wordtoix[word] for word in start.split() if word in wordtoix]
        seq = pad_sequences([seq], maxlen = max_length)
        yhat = model1.predict([pic, seq])
        yhat = np.argmax(yhat)
        word = ixtoword[yhat]
        start += ' ' + word
        if word == 'end':
            break
    final = start.split()
    final = final[1:-1]
    final = ' '.join(final)
    return final


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['GET', 'POST'])
def after():
    file = request.files['file1']
    file.save('static/file1.jpg')
    caption = predict('static/file1.jpg')
    print(caption)
    return render_template('/predict.html', data = caption)


if __name__ == "__main__":
    app.run(debug=True)
